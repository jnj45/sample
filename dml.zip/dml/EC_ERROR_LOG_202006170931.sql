INSERT INTO ESS.dbo.EC_ERROR_LOG (ErrorTime,UserName,ErrorNumber,ErrorSeverity,ErrorState,ErrorProcedure,ErrorLine,ErrorMessage) VALUES 
('2020-06-16 19:23:48.960','ess',8115,16,8,'dbo.sp_mig_ep_po_hd',349,'numeric을(를) 데이터 형식 numeric(으)로 변환하는 중 산술 오버플로 오류가 발생했습니다.')
,('2020-06-16 19:23:53.553','ess',8152,16,14,'dbo.sp_mig_ep_po_item',254,'문자열이나 이진 데이터는 잘립니다.')
,('2020-06-17 09:25:13.063','ess',515,16,2,'dbo.sp_mig_eo_po_item',277,'테이블 ''ESS.dbo.EO_PO_ITEM'', 열 ''CO_CD''에 NULL 값을 삽입할 수 없습니다. 열에는 NULL을 사용할 수 없습니다. INSERT이(가) 실패했습니다.')
,('2020-06-16 19:24:11.087','ess',8152,16,14,'dbo.sp_mig_ep_rfx_item',150,'문자열이나 이진 데이터는 잘립니다.')
;