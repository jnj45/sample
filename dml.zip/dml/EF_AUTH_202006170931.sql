INSERT INTO ESS.dbo.EF_AUTH (AUTHOR_CODE,AUTHOR_NM,AUTHOR_DC,AUTHOR_CREAT_DE,AUTHOR_TYP) VALUES 
('IS_AUTHENTICATED_ANONYMOUSLY','스프링시큐리티 내부사용(롤부여 금지)','','05  8 2020  2:19PM  ','H')
,('IS_AUTHENTICATED_FULLY','스프링시큐리티 내부사용(롤부여 금지)','','05  8 2020  2:19PM  ','H')
,('IS_AUTHENTICATED_REMEMBERED','스프링시큐리티 내부사용(롤부여 금지)','','05  8 2020  2:19PM  ','H')
,('ROLE_ADMIN','관리자','','05  8 2020  2:19PM  ','I')
,('ROLE_ANONYMOUS','모든 사용자','','05  8 2020  2:19PM  ','H')
,('ROLE_APPROVAL','승인자',NULL,'05/27/2020          ','I')
,('ROLE_BUYER','구매담당자',NULL,'05/27/2020          ','I')
,('ROLE_BUYER_LOC','현지 구매담당자',NULL,'05/27/2020          ','I')
,('ROLE_DEVMASTER','개발 관리자',NULL,'05/27/2020          ','I')
,('ROLE_ERP','ERP발주서 출력',NULL,'05/27/2020          ','I')
;
INSERT INTO ESS.dbo.EF_AUTH (AUTHOR_CODE,AUTHOR_NM,AUTHOR_DC,AUTHOR_CREAT_DE,AUTHOR_TYP) VALUES 
('ROLE_MASTER','관리자',NULL,'05/27/2020          ','I')
,('ROLE_MRO','MRO담당자',NULL,'05/27/2020          ','I')
,('ROLE_OMANAGER','임가공업체관리자',NULL,'05/27/2020          ','I')
,('ROLE_OMASTER','임가공업체',NULL,'05/27/2020          ','O')
,('ROLE_PMANAGER','상품업체관리자',NULL,'05/27/2020          ','I')
,('ROLE_PMASTER','상품업체',NULL,'05/27/2020          ','O')
,('ROLE_PRGROUP','구매의뢰자',NULL,'05/27/2020          ','I')
,('ROLE_PRGROUP_R','구매의뢰연구원',NULL,'05/27/2020          ','I')
,('ROLE_PRGROUPRPT','구매의뢰자레포트',NULL,'05/27/2020          ','I')
,('ROLE_SMASTER','구매업체',NULL,'05/27/2020          ','O')
;
INSERT INTO ESS.dbo.EF_AUTH (AUTHOR_CODE,AUTHOR_NM,AUTHOR_DC,AUTHOR_CREAT_DE,AUTHOR_TYP) VALUES 
('ROLE_VOCMASTER','VOC관리',NULL,'05/27/2020          ','I')
;