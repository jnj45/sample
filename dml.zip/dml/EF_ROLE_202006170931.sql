INSERT INTO ESS.dbo.EF_ROLE (ROLE_CODE,ROLE_NM,ROLE_PTTRN,ROLE_DC,ROLE_TY,ROLE_SORT,ROLE_CREAT_DE) VALUES 
('egov_contents','전자정부 컨텐츠영역','/Egov.*\.do','컨텐츠영역에 대한 접근 제한 롤','url','1','05 11 2020 11:36AM  ')
,('login','로그인롤','\A/uat/uia/.*\.do.*\Z','로그인허용을 위한 롤','url','99','05 11 2020 11:36AM  ')
,('mng_CUD','관리 수정 롤','\A/mng/.*(regist|Regist|save|update|edit|delete).*\.do.*\Z','Admin 관리 수정 룰','url','1','20/05/28            ')
,('mng_R','관리 조회 롤','\A/mng/.*(select|List|ViewPop).*\.do.*\Z','Admin 관리 조회 룰','url','1','20/05/28            ')
,('sample_A','샘플 전체 롤','\A/sample/.*\.do.*\Z','샘플 조회 롤','url','99','05 11 2020 11:36AM  ')
,('sample_CUD','샘플 수정 롤','\A/sample/.*(regist|Regist|save|update|edit|Edit|delete).*\.do.*\Z','샘플 수정 롤','url','1','05 11 2020 11:36AM  ')
,('sample_R','샘플 조회 롤','\A/sample/.*(select|List|ViewPop).*\.do.*\Z','샘플 조회 롤','url','1','05 11 2020 11:36AM  ')
,('system_A','모든접근제한','\A/.*\.do.*\Z','모든자원에 대한 접근 제한 롤','url','999','05 11 2020 11:36AM  ')
;