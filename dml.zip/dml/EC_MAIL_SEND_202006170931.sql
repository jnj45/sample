INSERT INTO ESS.dbo.EC_MAIL_SEND (TITLE,REC_NAME,REC_EMAIL,CONTENTS,REG_DATE,SEND_DATE,TRY_COUNT,ERROR_MESSAGE,SENDER_NAME,SENDER_EMAIL,SEND_YN,MAIL_ID,REF_NO1,REF_NO2,CRT_ID,CRT_DT,MOD_ID,MOD_DT) VALUES 
('test','test','test@test.com','
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<table width="630" border="0" cellspacing="0" cellpadding="0" >
    <tr>
        <td><img src="http://www.skyebid.com/img/top.jpg" width="630" alt="top" /></td>
    </tr>
  <tr>
    <td td style="border-left:3px solid #dfdede; border-right:3px solid #dfdede; padding:30px 19px 10px 19px">
        <h1 style="font-size:12px; font-weight:bold; color:#e07c13;" ><!--메일제목-->
        <img src="http://www.skyebid.com/img/bullet.gif"  /> $frm.title </h1>
        <div style="border:2px solid #e3e7eb; line-height:16pt; padding:10px; text-align:left;  margin-top:10px; color:#474747; font-size:12px;">
        	$frm.chr_nm 님 <br/>        
			 아이디[$frm.usr_id] 비밀 번호[$frm.passwd] 입니다.		
        </div>
    </td>
  </tr>
  <tr>
      <td><img src="http://www.skyebid.com/img/footer.gif" /></td>
  </tr>
</table>
</body>
</html>','2020-05-20 16:19:57.700',NULL,3,NULL,'홍길동','test@test.com','N','1000',NULL,NULL,NULL,NULL,'SYSTEM','2020-06-16 16:10:05.870')
,('test','test','test@test.com','
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<table width="630" border="0" cellspacing="0" cellpadding="0" >
    <tr>
        <td><img src="http://www.skyebid.com/img/top.jpg" width="630" alt="top" /></td>
    </tr>
  <tr>
    <td td style="border-left:3px solid #dfdede; border-right:3px solid #dfdede; padding:30px 19px 10px 19px">
        <h1 style="font-size:12px; font-weight:bold; color:#e07c13;" ><!--메일제목-->
        <img src="http://www.skyebid.com/img/bullet.gif"  /> $frm.title </h1>
        <div style="border:2px solid #e3e7eb; line-height:16pt; padding:10px; text-align:left;  margin-top:10px; color:#474747; font-size:12px;">
        	$frm.chr_nm 님 <br/>        
			 아이디[$frm.usr_id] 비밀 번호[$frm.passwd] 입니다.		
        </div>
    </td>
  </tr>
  <tr>
      <td><img src="http://www.skyebid.com/img/footer.gif" /></td>
  </tr>
</table>
</body>
</html>','2020-05-20 16:28:56.690',NULL,3,NULL,'홍길동','test@test.com','N','1000',NULL,NULL,NULL,NULL,'SYSTEM','2020-06-16 16:10:07.917')
,('test','test','test@test.com','
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<table width="630" border="0" cellspacing="0" cellpadding="0" >
    <tr>
        <td><img src="http://www.skyebid.com/img/top.jpg" width="630" alt="top" /></td>
    </tr>
  <tr>
    <td td style="border-left:3px solid #dfdede; border-right:3px solid #dfdede; padding:30px 19px 10px 19px">
        <h1 style="font-size:12px; font-weight:bold; color:#e07c13;" ><!--메일제목-->
        <img src="http://www.skyebid.com/img/bullet.gif"  /> $frm.title </h1>
        <div style="border:2px solid #e3e7eb; line-height:16pt; padding:10px; text-align:left;  margin-top:10px; color:#474747; font-size:12px;">
        	$frm.chr_nm 님 <br/>        
			 아이디[$frm.usr_id] 비밀 번호[$frm.passwd] 입니다.		
        </div>
    </td>
  </tr>
  <tr>
      <td><img src="http://www.skyebid.com/img/footer.gif" /></td>
  </tr>
</table>
</body>
</html>','2020-05-20 16:39:07.457',NULL,3,NULL,'홍길동','test@test.com','N','1000',NULL,NULL,NULL,NULL,'SYSTEM','2020-06-16 16:10:09.993')
,('test','test','test@test.com','
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<table width="630" border="0" cellspacing="0" cellpadding="0" >
    <tr>
        <td><img src="http://www.skyebid.com/img/top.jpg" width="630" alt="top" /></td>
    </tr>
  <tr>
    <td td style="border-left:3px solid #dfdede; border-right:3px solid #dfdede; padding:30px 19px 10px 19px">
        <h1 style="font-size:12px; font-weight:bold; color:#e07c13;" ><!--메일제목-->
        <img src="http://www.skyebid.com/img/bullet.gif"  /> $frm.title </h1>
        <div style="border:2px solid #e3e7eb; line-height:16pt; padding:10px; text-align:left;  margin-top:10px; color:#474747; font-size:12px;">
        	$frm.chr_nm 님 <br/>        
			 아이디[$frm.usr_id] 비밀 번호[$frm.passwd] 입니다.		
        </div>
    </td>
  </tr>
  <tr>
      <td><img src="http://www.skyebid.com/img/footer.gif" /></td>
  </tr>
</table>
</body>
</html>','2020-05-20 16:44:32.210',NULL,3,NULL,'홍길동','test@test.com','N','1000',NULL,NULL,NULL,NULL,'SYSTEM','2020-06-16 16:10:12.070')
,('fweef','dfsd','test@test.com','
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<table width="630" border="0" cellspacing="0" cellpadding="0" >
    <tr>
        <td><img src="http://www.skyebid.com/img/top.jpg" width="630" alt="top" /></td>
    </tr>
  <tr>
    <td td style="border-left:3px solid #dfdede; border-right:3px solid #dfdede; padding:30px 19px 10px 19px">
        <h1 style="font-size:12px; font-weight:bold; color:#e07c13;" ><!--메일제목-->
        <img src="http://www.skyebid.com/img/bullet.gif"  /> $frm.title </h1>
        <div style="border:2px solid #e3e7eb; line-height:16pt; padding:10px; text-align:left;  margin-top:10px; color:#474747; font-size:12px;">
        	$frm.chr_nm 님 <br/>        
			 아이디[$frm.usr_id] 비밀 번호[$frm.passwd] 입니다.		
        </div>
    </td>
  </tr>
  <tr>
      <td><img src="http://www.skyebid.com/img/footer.gif" /></td>
  </tr>
</table>
</body>
</html>','2020-05-20 16:47:15.903',NULL,3,NULL,'홍길동','test@test.com','N','1000',NULL,NULL,NULL,NULL,'SYSTEM','2020-06-16 16:10:14.133')
,('fweef','dfsd','test@test.com','
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<table width="630" border="0" cellspacing="0" cellpadding="0" >
    <tr>
        <td><img src="http://www.skyebid.com/img/top.jpg" width="630" alt="top" /></td>
    </tr>
  <tr>
    <td td style="border-left:3px solid #dfdede; border-right:3px solid #dfdede; padding:30px 19px 10px 19px">
        <h1 style="font-size:12px; font-weight:bold; color:#e07c13;" ><!--메일제목-->
        <img src="http://www.skyebid.com/img/bullet.gif"  /> $frm.title </h1>
        <div style="border:2px solid #e3e7eb; line-height:16pt; padding:10px; text-align:left;  margin-top:10px; color:#474747; font-size:12px;">
        	$frm.chr_nm 님 <br/>        
			 아이디[$frm.usr_id] 비밀 번호[$frm.passwd] 입니다.		
        </div>
    </td>
  </tr>
  <tr>
      <td><img src="http://www.skyebid.com/img/footer.gif" /></td>
  </tr>
</table>
</body>
</html>','2020-05-20 16:48:47.817',NULL,3,NULL,'홍길동','test@test.com','N','1000',NULL,NULL,NULL,NULL,'SYSTEM','2020-06-16 16:10:16.213')
,('TESSSSSS','강낭콩','tess@test.com','
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<table width="630" border="0" cellspacing="0" cellpadding="0" >
    <tr>
        <td><img src="http://www.skyebid.com/img/top.jpg" width="630" alt="top" /></td>
    </tr>
  <tr>
    <td td style="border-left:3px solid #dfdede; border-right:3px solid #dfdede; padding:30px 19px 10px 19px">
        <h1 style="font-size:12px; font-weight:bold; color:#e07c13;" ><!--메일제목-->
        <img src="http://www.skyebid.com/img/bullet.gif"  /> $frm.title </h1>
        <div style="border:2px solid #e3e7eb; line-height:16pt; padding:10px; text-align:left;  margin-top:10px; color:#474747; font-size:12px;">
        	$frm.chr_nm 님 <br/>        
			 아이디[$frm.usr_id] 비밀 번호[$frm.passwd] 입니다.		
        </div>
    </td>
  </tr>
  <tr>
      <td><img src="http://www.skyebid.com/img/footer.gif" /></td>
  </tr>
</table>
</body>
</html>','2020-05-20 17:11:16.823',NULL,3,NULL,'홍길동','test@test.com','N','1000',NULL,NULL,NULL,NULL,'SYSTEM','2020-06-16 16:10:18.323')
;