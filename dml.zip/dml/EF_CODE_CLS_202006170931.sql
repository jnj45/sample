INSERT INTO ESS.dbo.EF_CODE_CLS (CL_CODE,CL_CODE_NM,CL_CODE_DC,USE_AT,FRST_REGIST_PNTTM,FRST_REGISTER_ID,LAST_UPDT_PNTTM,LAST_UPDUSR_ID) VALUES 
('CNT','계약관리','계약관리','Y',NULL,'SYSTEM',NULL,'SYSTEM')
,('COM','공통관리','공통관리','Y',NULL,'SYSTEM',NULL,'SYSTEM')
,('EFC','전자정부 프레임워크 공통서비스','전자정부 프레임워크 공통서비스','Y','2020-05-08 14:19:07.590','SYSTEM','2020-05-08 14:19:07.590','SYSTEM')
,('MST','기준정보','기준정보','Y',NULL,'SYSTEM',NULL,'SYSTEM')
,('OSP','임가공관리','임가공관리','Y',NULL,'SYSTEM',NULL,'SYSTEM')
,('PRO','구매관리','구매관리','Y',NULL,'SYSTEM',NULL,'SYSTEM')
,('QCM','품질관리','품질관리','Y',NULL,'SYSTEM',NULL,'SYSTEM')
,('SRM','구매포탈','구매포탈','N','2020-05-08 14:19:07.590','SYSTEM','2020-05-08 14:19:07.590','SYSTEM')
,('VND','협력업체','협력업체','Y',NULL,'SYSTEM',NULL,'SYSTEM')
;